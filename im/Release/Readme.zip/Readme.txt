==== Impossible Mission ====
------ Twilighte 2010 -V0.1-

>> Setup Instructions
For Sedoric Disk users type QUIT:CLOAD"I2"
For Oric-1 and Atmos Tape only type CLOAD"I2"

>> Game Controls
On bootup you are at the title shown in the little window in the scorepanel.
Press Fire(Space) to start game or move to take you to Title Options.

In game controls are Cursor keys with any 'other' key being treated as Fire.

>> Title Options(5 options)
Each of the 5 options shows its current state.
EASY          Difficulty        - Choose between EASY(6 hours), DIFFICULT(4 Hours) or IMPOSSIBLE(2 Hours)
COLOUR        Colour Scheme     - Choose between COLOUR and MONOCHROME
AUDIO ON      Sound             - Choose between AUDIO ON and AUDIO OFF
LOAD GAME     Load Game Session - Only use this option if you've previously saved your session
BACK TO TITLE Quit back to main title

The cursor on the left shows the currently selected option.
Press Fire(Space) to change an option



